#include<stdio.h>
int func4(int a1, int a2, int a3)
{
  int v3; // edx
  int result; // eax

  v3 = (a3 - a2) / 2 + a2;
  if ( v3 > a1 )
    return 2 * func4(a1, a2, v3 - 1);
  result = 0;
  if ( v3 < a1 )
    result = 2 * func4(a1, v3 + 1, a3) + 1;
  return result;
}
int main()
{
	for(int i=0;i<=14;i++)
	if(func4(i,0,14)==1)
	printf("%d\n",i);
}
  
